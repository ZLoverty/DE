# Illustrations

Save the project files of illustrations for double emulsion project.
For example, when making a vector graphics drawing, I always have a *.svg file as the project file, which I can go back and modify further in the future.
The versions that are actually used in notes and papers are copied to the folders of *.tex files.
