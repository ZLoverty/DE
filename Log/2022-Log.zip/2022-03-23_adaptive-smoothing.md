---
layout: "post"
title: "adaptive smoothing"
date: "2022-03-23 10:56"
---

### Adaptive smoothing of velocity fields for VACF computation

In the previous VACF note, we saw that smoothing over time is required for obtaining a smooth VACF. Insufficient smoothing can result in very rapid decrease of VACF in the short time regime, as can be seen in _curve 6_ in the figure below.

![VACF data](../images/2022/03/vacf-data.png)

For all the velocities fields, I applied a gaussian filter of $3\Delta t_{min}$ to for smoothing. This works pretty well for velocity fields 0-4, but start to be insufficient for 5-6. The main difference between 0-4 and 5-6 is the bacterial activity: 0-4 show higher activity, with mean velocity ~10 $\mu$m/s, whereas 5-6 show lower activity, with mean velocity ~4 $\mu$m/s.

This VACF data suggests that a better smoothing method, preferably an adaptive one, is needed.

##### Gaussian filter and `smoothn`

For 5-6, a larger smoothing window can make the rapid decrease of VACF at short times disappear. However, if the window $s > \tau$, the correlation time of fast velocity field, the VACF will depend on the smoothing window choices and the measured correlation time will shift up. Therefore, fixing the smoothing window size is not ideal and requires a lot of human corrections after the VACF calculation.

An iterative robust scheme of a DCT-based penalized regression, developed by Damien Garcia (Garcia 2010), can potentially solve this problem. In the following, we compare the VACF results from Gaussian filter and `smoothn` and show that `smoothn` improves the smoothing quality.

As illustrated in the figure below, where I plot the VACF of the same velocity field (corresponding to curve 6 in the previous figure, using smoothing window size 3 results in rapid decrease at short time due to noise), but smoothed using different methods. The viridis colored curves represent Gaussian smoothing with smoothing window sizes ranging from 0 to 40. The red curve represents smoothing done by the  `smoothn` function .

![smoothing window affects corr time](../images/2022/03/smoothing-window-affects-corr-time.png)


### Reference

Garcia, Damien. “Robust Smoothing of Gridded Data in One and Higher Dimensions with Missing Values.” Computational Statistics & Data Analysis 54, no. 4 (April 2010): 1167–78. https://doi.org/10.1016/j.csda.2009.09.020.
