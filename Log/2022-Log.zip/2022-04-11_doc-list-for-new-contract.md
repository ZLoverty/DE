---
layout: "post"
title: "doc list for new contract"
date: "2022-04-11 11:51"
---

# Doc list
- [x] Copy of national identity card or extract of birth certificate or copy of passport,
- [x] Bank or post-office account identification form (RIB and statement OK?)

- [x] Copy of diploma corresponding to recruitment level,
- [ ] medical certificate of fitness for work by an approved doctor, (where to get this?)
- [ ] copy of family record book, (what is this?)
- [ ] For the first day of work : certificate of termination of payment from the last employer (public sector) or sworn statement of non-employment or non-accumulation with Pôle Emploi allowances, (need to ask fred prob)
- [ ] For citizens of countries outside the European Union, proof of legal residency in France: copy of residence or work permit, employment authorization issued by the prefecture if this is not stated on the residence permit, (need contract to renew residency permit)
- [ ] Documents justifying of a tax residence abroad, if necessary, (necessary?)
- [x] Public sector : enclose copies of concurrent salary authorization and pay-slip for the relevant month,

birth certificate:
- [ ] Copy of national health insurance certificate or extract of birth certificate (if not registered with national health insurance),
- [ ] For foreign citizens, copy of military service papers, birth certificate with filiation (translated in french) and A1 Form or certificate of maintenance to a foreign mode of social security, if necessary.
