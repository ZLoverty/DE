---
layout: "post"
title: "effective temperature"
date: "2022-05-04 11:00"
---

### Literature review -- Effective temperature of an active bath

##### Wu and Libchaber 2000: fluctuation-dissipation

They studied the diffusion of PS particles of 4.5 and 10 $\mu$m in _E. coli_ bath, and found the effective diffusivity to be $1.0\times 10^{-6}$ cm$^2$/s and $4.3\times 10^{-7}$ cm$^2$/s, respectively. Compared to the thermal diffusivity $D_T\sim 10^{-9}$ cm$^2$/s, the active bath enhances the diffusivity about 100 times greater. With the Stokes-Einstein relation,
$$
D = \frac{k_BT}{6\pi\eta R},
$$
this enhanced diffusivity implies an effective temperature of the active bath 100 times greater than room temperature, i.e. $T_{eff} \approx 30000$ K.

##### Palacci et al. 2010: average potential, fluctuation-dissipation

They studied the stationary distributions of active Janus particles (latex) in the gravity potential (the Jean-Perrin experiment for active colloids). The balance between gravitational sedimentation and diffusion leads to a steady Boltzmann distribution profile
$$
\rho(z) = \rho_0\exp(-z/\delta_{eff}),
$$
where $\rho_0$ is the normalizing factor, $z$ is the position in gravity direction, and $\delta_{eff}$ is the effective sedimentation length, corresponding to the length over which particle density drops by $1/e$.

Using a piezo-mounted microscope, they scanned the sample chamber over $z$ to measure the stationary distribution of particle number. The density profiles are shown to be dependent on the $D_{eff}$ of individual active particles.

![particle distribution](../images/2022/05/particle-distribution.png)

Effective temperature can be recovered by
$$
\delta_{eff} = \frac{k_B T_{eff}}{mg},
$$
where $m$ is the buoyant mass of particles. For a sedimentation length 6 $\mu$m, the effective temperature is
$$
T_{eff} = \frac{\delta_{eff}mg}{k_B}=\frac{6\times 10^{-6} \times 55 \times 5.2 \times 10^{-19}\times 10}{1.38\times 10^{-23}} = 124 \:\text{K}.
$$
This is approximately a factor of two difference from the data shown in the paper. I'm not sure what is missing in my calculation but for now I'm more concerned about the order of magnitude.

In the same system, the diffusivity of individual particles also has an associated effective temperature, which can be calculated by
$$
D_{eff} = \frac{k_BT_{eff}}{6\pi\eta R},
$$
where $\eta=0.001$ Pa s is water viscosity and $R=0.5$ $\mu$m is particle radius. For $D_{eff}\approx 0.3$ $\mu$m$^2$/s, which corresponds to 6 $\mu$m sedimentation length, the effective temperature is
$$
T_{eff} = \frac{6\pi\eta R D_{eff}}{k_B}=\frac{6\pi\times 0.001\times 0.5\times 10^{-6}\times 0.3\times 10^{-12}}{1.38\times 10^{-23}} = 205 \:\text{K}.
$$
<font color="red">My calculation gives two different effective temperatures. What is wrong?</font>

##### Maggi et al. 2014: average potential

They studied the motion of glass beads confined at the bottom of a cylindrical capillary. They found that the probability distribution of the glass bead can be well approximated by a Gaussian distribution
$$
P(y)\sim \exp(-ky^2/2k_BT_{eff}).
$$
Consider a particle randomly fluctuating in a harmonic potential, the higher the temperature, the farther it will explore the potential well. An active bath also induce fluctuations. In this way, the **average potential** energy acquired by the fluctuating particle is a measure of effective temperature.

The average potential is calculated as
$$
U = \frac{1}{2}k\langle y^2\rangle = \frac{1}{2}k\lim_{t\to\infty}\langle \Delta y^2(t)\rangle/2,
$$
where the second equation can be understood like this: the mean square displacement $\langle \Delta y^2(t)\rangle$ considers the displacement from one side of the potential well to the other side, therefore it is twice the displacement from the equilibrium position statistically.

Then, using $U=k_BT_{eff}/2$, we can calculate $T_{eff}$ as
$$
T_{eff} = \frac{2U}{k_B} =  \frac{k\langle \Delta y^2(t)\rangle_{max}}{2k_B},
$$
where $k=m^*g/(r_o-r_i)=1.4\times 10^{-7}$ kg/s$^2$. In the paper, they present 3 $\langle \Delta y^2(t)\rangle_{max}$ values: 2, 1 and 0.1 $\mu$m$^2$, corresponding to being close to air bubble, being far from air bubble and in the absence of bacteria. The effective temperatures corresponding to these scenarios can be calculated:
$$
T_{close} = \frac{2\times 1.4\times10^{-7}\times 2\times 10^{-12}}{1.38\times 10^{-23}} \approx 40000 \:\text{K}\\
T_{far} = \frac{2\times 1.4\times10^{-7}\times 1\times 10^{-12}}{1.38\times 10^{-23}} \approx 20000 \:\text{K}\\
T_{nobac}=\frac{2\times 1.4\times10^{-7}\times 0.1\times 10^{-12}}{1.38\times 10^{-23}} \approx 2000 \:\text{K}
$$
Although their results show similar effective temperature as Wu and Libchaber, the no-bacteria scenario does not recover room temperature, posing a question of using average potential to measure temperature.

##### Ye et al. 2020

They consider three definitions of effective temperature: fluctuation-dissipation $D_{eff}/\mu$, mean kinetic energy $E$ and mean potential energy $U$. In some scenarios, these definitions can be shown to be equivalent. For example, from a straightforward generalization of Stokes-Einstein relation, we have
$$
D_{eff} = \mu k_B T_{eff}
$$
The potential energy by definition is related to the effective temperature $k_B$
$$
U = \frac{1}{2} k_B T_{eff}
$$
Here, both $D_{eff}$ and $U$ can be measured from the trajectory of the passive particle. If we assume the motion is in the negligible inertia regime (low *Re*), governed by an exponentially correlated noise and a harmonic potential, we can solve the overdamped Langevin equation
$$
\mathbf{\dot r} = \mu\mathbf{f(r)} + \mathbf{\eta^A} + \mathbf{\eta^T}
$$
with $\mathbf{f(r)}=-k\mathbf{r}$ being the restoring force from the confinement by the external trap, or in our case the curved surface of outer droplet.

The solution of this equation gives the MSD of the passive particle
$$
\left< \Delta y^2(t) \right> = \frac{2D_A}{\mu k} \frac{1-e^{-\mu kt} - \mu k\tau(1-e^{-t/\tau})}{1-(\mu k\tau)^2}
$$
Notes:
1. The inner droplets in our case are typically big so that the thermal noisy is negligible compared to the active noise.
2. ...

We have already calculated the average potential in the previous discussion
$$
U = \frac{1}{2}k\langle y^2\rangle = \frac{1}{2}k\lim_{t\to\infty}\langle \Delta y^2(t)\rangle/2.
$$
Using the MSD solution, we get
$$
U = \frac{1}{2} \frac{D_A}{\mu}\frac{1}{1+\mu k \tau}
$$
In most experiments, $\mu k\tau \ll 1$ so we can approximate
$$
U \approx \frac{D_A}{2\mu}=\frac{1}{2}k_BT_{eff}.
$$
The second equation comes from the Stokes-Einstein relation, with $D_A$ being equivalent to the effective diffusivity $D_{eff}$.

In summary, if we assume
1. Langevin dynamics
2. $\mu k\tau \ll 1$

The effective temperatures defined by fluctuation-dissipation relation, and average potential, are equivalent. Moreover, if we lift the second assumption, by letting $\mu k\tau \sim 1$ or $\mu k\tau > 1$, but keep the Langevin dynamics, the average potential is
$$
U=\frac{D_A}{2\mu}\frac{1}{1+\mu k\tau}
$$
If we force the definition of effective diffusivity and effective temperature, we can let think in this way: in the absence of external potential, the effective diffusivity $D_{eff}$ and the active diffusivity (magnitude of active noise) are equivalent; in the presence of an external harmonic potential, however, $D_{eff}$ is modified by the potential by a factor of $1/(1+\mu k\tau)$. This transition from equivalence to non-equivalence between $D_A$ and $D_{eff}$ is the key discovery of Maggi et al. 2014.

From an experimental point of view, we can access the trajectories of passive particles. Assuming Langevin dynamics to hold, we can fit the MSD to get $D_A$. This $D_A$ is not equivalent to $D_{eff}$, and has to be modified by $1/(1+\mu k\tau)$. In other words, when doing the fitting using the Langevin model, we've already consider the **apparent effect** from the external potential. However, there are **potential hidden effects** of boundaries (or external potentials) that can further modify $D_{eff}$, e.g. through modifying $D_A$ (more specifically, modifying bacterial swimming). This leads to the argument "active noise is not intrinsic to active bath" pointed out in Ye et al. 2020. Our experiment will likely arrive at this conclusion, too.

Below I plot $D_A$ fitted from our experiments as a function of $D-d$ ($OD\in[60, 80]$). The dependence of $D_A$ on boundaries is clear. To elucidate the underlying cause of this dependence, we have a few options to explore: i) examine outliers, ii) try to collapse data for different variables, iii) do more well controlled experiments.

![](../images/2022/05/DA_D-d.png)
